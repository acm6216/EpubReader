package cen.xiaoyuan.epub.data.usecase

import android.net.Uri
import cen.xiaoyuan.epub.data.Book
import cen.xiaoyuan.epub.data.BookDao
import cen.xiaoyuan.epub.data.Chapter
import cen.xiaoyuan.epub.data.Progress
import javax.inject.Inject

class BookInfoUseCase @Inject constructor(private val bookDao: BookDao) {

    suspend fun deleteBooks(books:List<Book>) = bookDao.deleteBooks(books)
    suspend fun insertBooks(books:List<Book>) = bookDao.insertBooks(books)
    fun queryBook(id: Uri) = bookDao.queryBook(id)
    fun queryBooks() = bookDao.queryBooks()
    suspend fun updateProgress(progress: Progress) = bookDao.updateProgress(progress)
    suspend fun updateProgressByUri(uri: Uri,position:Long) = bookDao.updateProgressByUri(uri,position)

    suspend fun insertReaderPosition(progress: List<Progress>) = bookDao.insertBookReaderProgress(progress)
    fun queryBookReaderProgress(uri: Uri) = bookDao.queryBookReaderProgress(uri)

    suspend fun insertChapters(chapters: List<Chapter>) = bookDao.insertChapters(chapters)
    fun queryChapters(uri: Uri) = bookDao.queryChapters(uri)

}