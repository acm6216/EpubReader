package cen.xiaoyuan.epub.ui.reader

import androidx.recyclerview.widget.RecyclerView
import androidx.viewbinding.ViewBinding

abstract class ReaderViewHolder<T:ViewBinding,K:ReaderItem>(
    protected open val binding:T
):RecyclerView.ViewHolder(binding.root) {
    open var data:K?=null
    abstract fun bind(item:K,viewModel: ReaderViewModel)
}