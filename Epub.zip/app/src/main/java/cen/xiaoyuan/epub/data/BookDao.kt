package cen.xiaoyuan.epub.data

import android.net.Uri
import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface BookDao {

    @Transaction
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBooks(books:List<Book>)

    @Transaction
    @Delete
    suspend fun deleteBooks(books:List<Book>)

    @Query("SELECT * FROM epub_books")
    fun queryBooks(): Flow<List<Book>>

    @Query("SELECT * FROM epub_books WHERE id=:uri")
    fun queryBook(uri: Uri):Book?

    @Transaction
    @Update
    suspend fun updateProgress(progress: Progress)

    @Transaction
    @Query("UPDATE epub_progress SET position=:position WHERE id=:uri")
    suspend fun updateProgressByUri(uri: Uri,position:Long)

    @Transaction
    @Insert
    suspend fun insertChapters(chapters: List<Chapter>)

    @Query("SELECT * FROM epub_chapters WHERE bookUri=:uri")
    fun queryChapters(uri:Uri):Flow<List<Chapter>?>

    @Transaction
    @Insert
    suspend fun insertBookReaderProgress(progress: List<Progress>)

    @Query("SELECT * FROM epub_progress WHERE id=:uri")
    fun queryBookReaderProgress(uri: Uri):Flow<Progress?>
}