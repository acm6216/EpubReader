package cen.xiaoyuan.epub.core

data class EpubChapter(val url: String, val title: String, val body: String)