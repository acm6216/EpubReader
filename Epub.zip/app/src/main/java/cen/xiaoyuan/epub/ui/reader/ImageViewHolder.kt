package cen.xiaoyuan.epub.ui.reader

import android.view.ViewGroup
import android.widget.ImageView
import cen.xiaoyuan.epub.databinding.ReaderListItemImageBinding
import cen.xiaoyuan.epub.utils.layoutInflater

class ImageViewHolder private constructor(
    override val binding: ReaderListItemImageBinding
): ReaderViewHolder<ReaderListItemImageBinding,ReaderItem.Image>(binding){

    override fun bind(item: ReaderItem.Image,viewModel: ReaderViewModel){
        data = item
        binding.root.setOnClickListener { }
        viewModel.epubBook.value?.also {
            binding.image = ImageItem(it,item)
        }
        binding.executePendingBindings()
    }

    companion object{
        fun from(parent: ViewGroup) = ImageViewHolder(
            ReaderListItemImageBinding.inflate(parent.context.layoutInflater,parent,false)
        )
    }

}