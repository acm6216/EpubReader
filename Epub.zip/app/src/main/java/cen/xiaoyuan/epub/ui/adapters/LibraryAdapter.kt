package cen.xiaoyuan.epub.ui.adapters

import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import cen.xiaoyuan.epub.data.Book
import cen.xiaoyuan.epub.databinding.ItemLibraryBinding
import cen.xiaoyuan.epub.utils.layoutInflater

class LibraryAdapter(private val click:((Book,View,View)->Unit)?=null): ListAdapter<Book, LibraryAdapter.LibraryViewHolder>(
    LibraryDiffCallback()
) {

    override fun onBindViewHolder(holder: LibraryViewHolder, position: Int) = holder.bind(getItem(position),click)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = LibraryViewHolder.from(parent)

    class LibraryViewHolder private constructor(
        val binding:ItemLibraryBinding
    ): RecyclerView.ViewHolder(binding.root){

        fun bind(book: Book,click:((Book, View,View)->Unit)?=null){
            binding.book = book
            binding.click.setOnClickListener { click?.invoke(book,binding.root,binding.transitionName) }
            binding.executePendingBindings()
        }

        companion object{
            fun from(parent: ViewGroup) = LibraryViewHolder(ItemLibraryBinding.inflate(parent.context.layoutInflater,parent,false))
        }

    }
    class LibraryDiffCallback : DiffUtil.ItemCallback<Book>() {

        override fun areItemsTheSame(oldItem: Book, newItem: Book): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: Book, newItem: Book): Boolean {
            return oldItem == newItem
        }
    }
}