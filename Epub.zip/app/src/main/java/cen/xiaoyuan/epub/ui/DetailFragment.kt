package cen.xiaoyuan.epub.ui

import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.core.view.doOnPreDraw
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.navArgs
import cen.xiaoyuan.epub.R
import cen.xiaoyuan.epub.core.createEpubBook
import cen.xiaoyuan.epub.data.Book
import cen.xiaoyuan.epub.data.Chapter
import cen.xiaoyuan.epub.databinding.FragmentDetailBinding
import cen.xiaoyuan.epub.ui.adapters.ChapterAdapter
import cen.xiaoyuan.epub.ui.reader.ReaderViewModel
import cen.xiaoyuan.epub.ui.viewmodel.EventViewModel
import cen.xiaoyuan.epub.ui.viewmodel.LibraryViewModel
import cen.xiaoyuan.epub.utils.fadeToVisibilityUnsafe
import com.google.android.material.transition.MaterialContainerTransform
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class DetailFragment:BaseFragment<FragmentDetailBinding>() {

    override fun setBinding(): FragmentDetailBinding = FragmentDetailBinding.inflate(layoutInflater)

    private val args: DetailFragmentArgs by navArgs()
    private val library: LibraryViewModel by activityViewModels()
    private val events: EventViewModel by activityViewModels()
    private val reader: ReaderViewModel by activityViewModels()
    private val chapterAdapter = ChapterAdapter{ chapter,view ->
        reader.openItemByIndex(chapter)
        events.navigationToDetail(chapter)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        sharedElementEnterTransition = MaterialContainerTransform().apply {
            drawingViewId = R.id.nav_host_fragment_content_main
            duration = resources.getInteger(R.integer.motion_duration_large).toLong()
            scrimColor = Color.TRANSPARENT
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.chaptersView.adapter = chapterAdapter
        binding.executePendingBindings()
        args.id?.let {
            launch { library.findBook(Uri.parse(it)) }
        }
    }

    override fun launchFlow() {
        repeatWithViewLifecycle {
            launch{
                library.currentBook.collect{
                    it?.also {
                        binding.book = it
                        it.loadEpubBook()
                    }
                }
            }
            launch {
                library.currentBookChapters.collect{ list ->
                    list?.also {
                        chapterAdapter.submitList(it)
                        fade()
                    }
                }
            }
        }
    }

    private fun Book.loadEpubBook(){
        launch(Dispatchers.IO) {
            id.useInputStream {
                emptyTryCatch {
                    createEpubBook(it) { epub, _, _ ->
                        reader.openEpub(epub,this@loadEpubBook)
                        //epub?.chapters?.load()
                    }
                }
            }
        }
    }

    private fun fade(){
        launch(Dispatchers.Main.immediate) {
            binding.indicator.fadeToVisibilityUnsafe(false)
        }
    }

    override fun onDestroyView() {
        //library.release()
        //reader.release()
        super.onDestroyView()
    }

    companion object{
        private const val TAG = "ReaderFragment"
    }

}