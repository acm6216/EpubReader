package cen.xiaoyuan.epub.ui.reader

import android.view.ViewGroup
import cen.xiaoyuan.epub.databinding.ReaderListItemErrorBinding
import cen.xiaoyuan.epub.utils.layoutInflater

class ErrorViewHolder private constructor(
    override val binding: ReaderListItemErrorBinding
): ReaderViewHolder<ReaderListItemErrorBinding,ReaderItem.Error>(binding){

    override fun bind(item: ReaderItem.Error,viewModel: ReaderViewModel){
        binding.root.setOnClickListener { }
        binding.executePendingBindings()
    }

    companion object{
        fun from(parent: ViewGroup) = ErrorViewHolder(
            ReaderListItemErrorBinding.inflate(parent.context.layoutInflater,parent,false)
        )
    }

}