package cen.xiaoyuan.epub.ui

import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.navigation.findNavController
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.fragment.app.Fragment
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.navigation.NavController
import androidx.navigation.NavDestination
import cen.xiaoyuan.epub.R
import cen.xiaoyuan.epub.databinding.ActivityMainBinding
import cen.xiaoyuan.epub.ui.menu.*
import cen.xiaoyuan.epub.ui.reader.ReaderViewModel
import cen.xiaoyuan.epub.ui.viewmodel.EventViewModel
import com.google.android.material.bottomappbar.BottomAppBar
import com.google.android.material.transition.MaterialElevationScale
import com.google.android.material.transition.MaterialFadeThrough
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

@AndroidEntryPoint
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val navController: NavController get() = findNavController(R.id.nav_host_fragment_content_main)
    private val detailNavController:NavController? get() = findNavControllerNullable()
    private val events: EventViewModel by viewModels()
    private val reader: ReaderViewModel by viewModels()

    private val bottomNavMenu: BottomMenuFragment by lazy(LazyThreadSafetyMode.NONE) {
        supportFragmentManager.findFragmentById(R.id.bottom_nav_menu) as BottomMenuFragment
    }

    private val currentNavigationFragment: Fragment?
        get() = supportFragmentManager.findFragmentById(R.id.nav_host_fragment_content_main)
            ?.childFragmentManager
            ?.fragments
            ?.first()

    override fun onCreate(savedInstanceState: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.bottomAppBarContentContainer.setOnClickListener {
            bottomNavMenu.toggle()
        }
        bottomNavMenu.bind()
        binding.bottomAppBar.bind()


       /* binding.fab.setOnClickListener { view ->
            Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                .setAnchorView(R.id.fab)
                .setAction("Action", null).show()
        }*/

        detailNavController?.also {
            if(currentNavigationFragment is ReaderFragment)
                navController.navigateUp()
        }

        repeatWithViewLifecycle {
            launch {
                events.toDetail.collect{
                    if(detailNavController==null) toDetail()
                    else reader.navigationToDetail(it)
                }
            }
        }
        navController.addOnDestinationChangedListener{ _, destination, _ ->
            destination.id.replaceMenu()
            if(destination.id==R.id.fragment_reader)
                binding.bottomAppBar.performHide(true)
            else
                binding.bottomAppBar.performShow(true)
        }
    }

    private fun Int.replaceMenu(){
        binding.bottomAppBar.replaceMenu(
            when(this){
                R.id.fragment_detail -> R.menu.detail_menu
                R.id.fragment_library -> R.menu.library_menu
                else -> R.menu.reader_menu
            }
        )
    }

    private fun toDetail(){
        currentNavigationFragment?.apply {
            exitTransition = MaterialFadeThrough().apply {
                duration = resources.getInteger(R.integer.motion_duration_large).toLong()
            }
            navController.navigate(R.id.fragment_reader)
        }
    }

    private fun BottomAppBar.bind(){
        setOnMenuItemClickListener {
            when(it.itemId){
                R.id.library_add_file -> events.addEpub(true)
                R.id.library_add_folder -> events.addEpub(false)
                R.id.detail_continue -> detailNavController?:toDetail()
            }
            true
        }
    }

    private fun BottomMenuFragment.bind() {
        addOnSlideAction(HalfClockwiseRotateSlideAction(binding.bottomAppBarChevron))
        addOnSlideAction(AlphaSlideAction(binding.bottomAppBarTitle, true))
        /*addOnStateChangedAction(
            ShowHideFabStateAction(
                binding.fab, navController, intArrayOf(
                    R.id.search_fragment, R.id.settings_fragment, R.id.playing_fragment
                )
            )
        )*/
        addOnStateChangedAction(ChangeSettingsMenuStateAction { showSettings ->
            /*binding.bottomAppBar.replaceMenu(
                if (showSettings) R.menu.bottom_app_bar_settings_menu
                else getBottomAppBarMenuForDestination()
            )*/
        })

        setNavigationListener { id, titleId, _ ->
            binding.bottomAppBarTitle.setText(titleId)
            /*when (id) {
                R.id.to_about -> navigateToStyle()
                else -> navigateToHome(
                    titleId, when (id) {
                        R.id.to_album -> MusicBox.ALBUM
                        R.id.to_artist -> MusicBox.ARTIST
                        R.id.to_favorite -> MusicBox.FAVORITE
                        else -> MusicBox.MUSIC_LIBRARY
                    }
                )
            }*/
        }
    }

    private fun findNavControllerNullable():NavController?{
        val nav:NavController? = try {
            findNavController(R.id.nav_host_fragment_content_detail)
        }catch (_:Exception){ null }
        return nav
    }


    private inline fun AppCompatActivity.repeatWithViewLifecycle(
        minState: Lifecycle.State = Lifecycle.State.STARTED,
        crossinline block: suspend CoroutineScope.() -> Unit
    ) {
        if (minState == Lifecycle.State.INITIALIZED || minState == Lifecycle.State.DESTROYED) {
            throw IllegalArgumentException("minState must be between INITIALIZED and DESTROYED")
        }
        lifecycleScope.launch {
            lifecycle.repeatOnLifecycle(minState) {
                block()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        return false
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        return navController.navigateUp() || super.onSupportNavigateUp()
    }
}