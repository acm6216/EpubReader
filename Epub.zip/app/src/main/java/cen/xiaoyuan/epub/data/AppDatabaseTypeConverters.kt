package cen.xiaoyuan.epub.data

import android.net.Uri
import androidx.room.TypeConverter
import java.time.Instant

class AppDatabaseTypeConverters {

    @TypeConverter
    fun uriToString(value: Uri): String = value.toString()

    @TypeConverter
    fun stringToUri(value:String):Uri = Uri.parse(value)
}