package cen.xiaoyuan.epub

import android.app.Application
import cen.xiaoyuan.epub.fetcher.EpubImageFetcher
import cen.xiaoyuan.epub.utils.SpManager
import coil.ImageLoader
import coil.ImageLoaderFactory
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class App:Application(), ImageLoaderFactory {
    override fun onCreate() {
        super.onCreate()
        SpManager.init(this)
    }

    @Inject
    lateinit var imageFetcher: EpubImageFetcher

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .componentRegistry {
                add(imageFetcher)
            }.build()
}