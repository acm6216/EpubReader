package cen.xiaoyuan.epub.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.doOnPreDraw
import androidx.documentfile.provider.DocumentFile
import androidx.fragment.app.activityViewModels
import androidx.navigation.fragment.FragmentNavigatorExtras
import androidx.navigation.fragment.findNavController
import cen.xiaoyuan.epub.Config
import cen.xiaoyuan.epub.R
import cen.xiaoyuan.epub.core.EpubBook
import cen.xiaoyuan.epub.core.createEpubBook
import cen.xiaoyuan.epub.databinding.FragmentLibraryBinding
import cen.xiaoyuan.epub.ui.adapters.LibraryAdapter
import cen.xiaoyuan.epub.ui.viewmodel.EventViewModel
import cen.xiaoyuan.epub.ui.viewmodel.LibraryViewModel
import cen.xiaoyuan.epub.utils.coverFolder
import cen.xiaoyuan.epub.utils.fadeToVisibilityUnsafe
import com.google.android.material.transition.MaterialElevationScale
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.launch
import java.io.File

@AndroidEntryPoint
class LibraryFragment : BaseFragment<FragmentLibraryBinding>() {

    private val events: EventViewModel by activityViewModels()
    private val library: LibraryViewModel by activityViewModels()
    private val libraryAdapter = LibraryAdapter { book, view1, view2 ->
        val cardDetailTransitionName = getString(R.string.library_card_detail_transition_const)
        val coverDetailTransitionName = getString(R.string.library_card_detail_transition_cover)
        val extras = FragmentNavigatorExtras(
            view1 to cardDetailTransitionName,
            view2 to coverDetailTransitionName
        )
        val directions = LibraryFragmentDirections.toDetail(book.id.toString())
        findNavController().navigateUp()
        findNavController().navigate(directions, extras)
    }

    private val document =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uri ->
            uri?.process()
        }

    private val documentTree =
        registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
            uri?.let {
                requireContext().contentResolver.takePersistableUriPermission(
                    it, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        exitTransition = MaterialElevationScale(false).apply {
            duration = resources.getInteger(R.integer.motion_duration_large).toLong()
        }
        reenterTransition = MaterialElevationScale(true).apply {
            duration = resources.getInteger(R.integer.motion_duration_large).toLong()
        }
    }

    override fun setBinding(): FragmentLibraryBinding =
        FragmentLibraryBinding.inflate(layoutInflater)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        postponeEnterTransition()
        view.doOnPreDraw { startPostponedEnterTransition() }
        binding.recyclerView.adapter = libraryAdapter
        false.fade()
    }

    private fun Boolean.fade() = binding.indicator.fadeToVisibilityUnsafe(this)

    private fun List<Uri>.process() {
        true.fade()
        this.forEach { uri ->
            DocumentFile.fromSingleUri(requireContext(), uri)?.infoProcess { success, message ->

                Log.d(TAG, "processs: $success")
            }
        }
        false.fade()
    }

    private fun DocumentFile.infoProcess(block: ((Boolean, String) -> Unit)) {
        launch(Dispatchers.IO) {
            uri.useInputStream { inputStream ->
                emptyTryCatch {
                    createEpubBook(inputStream) { epub, success, message ->
                        if (success) {
                            uri.takePersistableUriPermission()
                            launch { epub?.addDatabase(uri) }
                        }
                        block(success, message)
                    }
                }
            }
        }
    }

    private suspend fun EpubBook.addDatabase(uri: Uri) {
        library.addBook(uri,this,requireContext())
    }

    private fun Uri.takePersistableUriPermission(): Uri {
        requireContext().contentResolver.takePersistableUriPermission(
            this, Intent.FLAG_GRANT_READ_URI_PERMISSION
        )
        return this
    }

    override fun click() {

    }

    override fun launchFlow() {
        repeatWithViewLifecycle {
            launch {
                events.addEpub.collect { isFile ->
                    if (isFile) document.launch(arrayOf(Config.EPUB_FILE_MIME))
                    else documentTree.launch(null)
                }
            }
            launch {
                library.books.collect {
                    libraryAdapter.submitList(it)
                }
            }
        }
    }

    companion object {
        private const val TAG = "LibraryFragment"
    }

}