package cen.xiaoyuan.epub.ui.reader

import android.view.ViewGroup
import android.widget.ImageView
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView

class ReaderAdapter(
    private val viewModel: ReaderViewModel
): ListAdapter<ReaderItem,RecyclerView.ViewHolder>(
    ReaderDiffCallback()
) {

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int){
        when(holder){
            is BodyViewHolder -> holder.bind(getItem(position) as ReaderItem.Body,viewModel)
            is ImageViewHolder -> holder.also {
                it.bind(getItem(position) as ReaderItem.Image,viewModel)
            }
            is BookEndViewHolder -> holder.bind(getItem(position) as ReaderItem.BookEnd,viewModel)
            is BookStartViewHolder -> holder.bind(getItem(position) as ReaderItem.BookStart,viewModel)
            is DividerViewHolder -> holder.bind(getItem(position) as ReaderItem.Divider,viewModel)
            is ErrorViewHolder -> holder.bind(getItem(position) as ReaderItem.Error,viewModel)
            is PaddingViewHolder -> holder.bind(getItem(position) as ReaderItem.Padding,viewModel)
            is ProgressbarViewHolder -> holder.bind(getItem(position) as ReaderItem.Progressbar,viewModel)
            is TitleViewHolder -> holder.bind(getItem(position) as ReaderItem.Title,viewModel)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder =
        when(viewType){
            READER_ITEM_BODY -> BodyViewHolder.from(parent)
            READER_ITEM_IMAGE -> ImageViewHolder.from(parent)
            READER_ITEM_BOOK_END -> BookEndViewHolder.from(parent)
            READER_ITEM_BOOK_START -> BookStartViewHolder.from(parent)
            READER_ITEM_DIVIDER -> DividerViewHolder.from(parent)
            READER_ITEM_ERROR -> ErrorViewHolder.from(parent)
            READER_ITEM_PADDING -> PaddingViewHolder.from(parent)
            READER_ITEM_PROGRESS_BAR -> ProgressbarViewHolder.from(parent)
            else -> TitleViewHolder.from(parent)
        }

    override fun getItemViewType(position: Int) = when (getItem(position)) {
        is ReaderItem.Body -> READER_ITEM_BODY
        is ReaderItem.Image -> READER_ITEM_IMAGE
        is ReaderItem.BookEnd -> READER_ITEM_BOOK_END
        is ReaderItem.BookStart -> READER_ITEM_BOOK_START
        is ReaderItem.Divider -> READER_ITEM_DIVIDER
        is ReaderItem.Error -> READER_ITEM_ERROR
        is ReaderItem.Padding -> READER_ITEM_PADDING
        is ReaderItem.Progressbar -> READER_ITEM_PROGRESS_BAR
        else -> READER_ITEM_TITLE
    }

    class ReaderDiffCallback : DiffUtil.ItemCallback<ReaderItem>() {

        override fun areItemsTheSame(oldItem: ReaderItem, newItem: ReaderItem): Boolean {
            return oldItem.chapterUrl == newItem.chapterUrl
        }

        override fun areContentsTheSame(oldItem: ReaderItem, newItem: ReaderItem): Boolean {
            return oldItem == newItem
        }
    }

    companion object{
        const val READER_ITEM_BODY = 0
        const val READER_ITEM_IMAGE = 1
        const val READER_ITEM_BOOK_END = 2
        const val READER_ITEM_BOOK_START = 3
        const val READER_ITEM_DIVIDER = 4
        const val READER_ITEM_ERROR = 5
        const val READER_ITEM_PADDING = 6
        const val READER_ITEM_PROGRESS_BAR = 7
        const val READER_ITEM_TITLE = 8
    }
}