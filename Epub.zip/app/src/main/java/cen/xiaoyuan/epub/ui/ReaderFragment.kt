package cen.xiaoyuan.epub.ui

import android.os.Bundle
import android.util.Log
import android.view.View
import androidx.activity.viewModels
import androidx.core.view.doOnPreDraw
import androidx.fragment.app.activityViewModels
import androidx.recyclerview.widget.RecyclerView
import cen.xiaoyuan.epub.R
import cen.xiaoyuan.epub.data.Chapter
import cen.xiaoyuan.epub.data.Progress
import cen.xiaoyuan.epub.databinding.FragmentReaderBinding
import cen.xiaoyuan.epub.ui.reader.ReaderAdapter
import cen.xiaoyuan.epub.ui.reader.ReaderViewModel
import cen.xiaoyuan.epub.ui.viewmodel.EventViewModel
import cen.xiaoyuan.epub.utils.fadeToVisibilityUnsafe
import com.google.android.material.transition.MaterialFadeThrough
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@AndroidEntryPoint
class ReaderFragment : BaseFragment<FragmentReaderBinding>() {

    override fun setBinding(): FragmentReaderBinding = FragmentReaderBinding.inflate(layoutInflater)

    private val reader: ReaderViewModel by activityViewModels()

    private var readerAdapter: ReaderAdapter? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        exitTransition = MaterialFadeThrough().apply {
            duration = resources.getInteger(R.integer.motion_duration_large).toLong()
        }
        enterTransition = MaterialFadeThrough().apply {
            duration = resources.getInteger(R.integer.motion_duration_large).toLong()
        }
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.indicator.fadeToVisibilityUnsafe(true)
        binding.adapter = ReaderAdapter(reader).also { readerAdapter = it }
        binding.overScroll.onScrollListener = {}
        binding.recyclerView.addOnScrollListener(object : RecyclerView.OnScrollListener() {
            override fun onScrollStateChanged(recyclerView: RecyclerView, newState: Int) {
                super.onScrollStateChanged(recyclerView, newState)
                if (recyclerView.childCount > 0) {
                    try {
                        reader.updateLastReaderIndex((recyclerView.getChildAt(0).layoutParams as RecyclerView.LayoutParams).viewAdapterPosition)
                    } catch (_:Exception) {}
                }
            }
        })
        binding.executePendingBindings()
    }

    override fun launchFlow() {
        repeatWithViewLifecycle {
            launch { reader.isLoading.collect { binding.indicator.fadeToVisibilityUnsafe(it) } }
            launch {
                reader.isLoading.collect{
                    if(!it) reader.progress.value?.lastReadPosition()
                }
            }
            launch {
                reader.epubContent.collect {
                    readerAdapter?.submitList(it)
                }
            }
            launch {
                reader.toDetail.collect{
                   it.also {
                       it.lastReadPosition()
                       reader.progress.value?.lastReadPosition()
                   }
                }
            }
        }
    }

    private fun Chapter.lastReadPosition(){
        Progress(
            id = bookUri,
            position = itemIndex,
            chapterIndex = chapterIndex.toInt()
        ).lastReadPosition()
    }

    private fun Progress.lastReadPosition(){
        launch(Dispatchers.Main.immediate) {
            binding.recyclerView.doOnPreDraw {
                binding.recyclerView.scrollToPosition(this@lastReadPosition.position.toInt())
            }
        }
    }

    override fun onDestroy() {
        reader.release()
        super.onDestroy()
    }

}