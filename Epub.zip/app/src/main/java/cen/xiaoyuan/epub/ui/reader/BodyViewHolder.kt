package cen.xiaoyuan.epub.ui.reader

import android.view.ViewGroup
import cen.xiaoyuan.epub.databinding.ReaderListItemBodyBinding
import cen.xiaoyuan.epub.utils.layoutInflater

class BodyViewHolder private constructor(
    override val binding: ReaderListItemBodyBinding
): ReaderViewHolder<ReaderListItemBodyBinding,ReaderItem.Body>(binding){

    override fun bind(item: ReaderItem.Body,viewModel: ReaderViewModel){
        binding.body = item
        binding.text.apply {
            setTextIsSelectable(false)
            post { setTextIsSelectable(true) }
        }
        binding.root.setOnClickListener { }
        binding.executePendingBindings()
    }

    companion object{
        fun from(parent: ViewGroup) = BodyViewHolder(
            ReaderListItemBodyBinding.inflate(parent.context.layoutInflater,parent,false)
        )
    }

}