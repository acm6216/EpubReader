package cen.xiaoyuan.epub.ui.views

import android.content.Context
import android.util.AttributeSet
import androidx.annotation.AttrRes
import androidx.appcompat.widget.AppCompatImageView

class AutoImageView:AppCompatImageView {

    constructor(context: Context) : super(context)
    constructor(context: Context, attrs: AttributeSet?) : super(context, attrs)
    constructor(context: Context, attrs: AttributeSet?, @AttrRes defStyleAttr: Int) : super(
        context, attrs, defStyleAttr)

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val specSize = MeasureSpec.getSize(widthMeasureSpec)
        setMeasuredDimension(specSize,measureHeight(specSize).toInt())
    }

    private fun measureHeight(specSize:Int):Float{
        return specSize.toFloat()*7/5
    }
}