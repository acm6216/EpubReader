package cen.xiaoyuan.epub.utils

import android.widget.ImageView
import androidx.databinding.BindingAdapter
import cen.xiaoyuan.epub.R
import cen.xiaoyuan.epub.data.Book
import cen.xiaoyuan.epub.ui.reader.ImageItem
import coil.load
import coil.loadAny
import java.io.File

@BindingAdapter(value = ["loadCover", "samplingValue"], requireAll = false)
fun ImageView.loadCover(book: Book?, samplingValue: Int = -1) {
    book ?: return
    load(File(book.coverPath)){
        size(240)
        crossfade(true)
    }
}

@BindingAdapter("load_image")
fun ImageView.loadImage(imageItem: ImageItem?){
    imageItem?:return
    loadAny(imageItem){
        crossfade(150)
        allowHardware(false)
        target(onSuccess = {
            setImageDrawable(it)
        }, onError = {
            setImageResource(R.drawable.ic_menu_book)
        }).build()
    }
}