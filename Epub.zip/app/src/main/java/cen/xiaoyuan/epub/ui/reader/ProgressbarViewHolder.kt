package cen.xiaoyuan.epub.ui.reader

import android.view.ViewGroup
import cen.xiaoyuan.epub.databinding.ReaderListItemProgressBarBinding
import cen.xiaoyuan.epub.utils.layoutInflater

class ProgressbarViewHolder private constructor(
    override val binding: ReaderListItemProgressBarBinding
): ReaderViewHolder<ReaderListItemProgressBarBinding,ReaderItem.Progressbar>(binding){

    override fun bind(item: ReaderItem.Progressbar,viewModel: ReaderViewModel){
        binding.root.setOnClickListener { }
        binding.executePendingBindings()
    }

    companion object{
        fun from(parent: ViewGroup) = ProgressbarViewHolder(
            ReaderListItemProgressBarBinding.inflate(parent.context.layoutInflater,parent,false)
        )
    }

}