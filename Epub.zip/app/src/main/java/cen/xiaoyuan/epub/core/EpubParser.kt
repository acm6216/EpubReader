package cen.xiaoyuan.epub.core

import org.jsoup.Jsoup
import org.jsoup.nodes.TextNode
import org.w3c.dom.Document
import org.w3c.dom.Element
import org.w3c.dom.Node
import org.w3c.dom.NodeList
import org.xml.sax.InputSource
import java.io.File
import java.io.InputStream
import java.net.URLDecoder
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

private val NodeList.elements get() = (0..length).asSequence().mapNotNull { item(it) as? Element }
private val Node.childElements get() = childNodes.elements
private fun Document.selectFirstTag(tag: String): Node? = getElementsByTagName(tag).item(0)
private fun Node.selectFirstChildTag(tag: String) = childElements.find { it.tagName == tag }
private fun Node.selectChildTag(tag: String) = childElements.filter { it.tagName == tag }
private fun Node.getAttributeValue(attribute: String): String? =
    attributes?.getNamedItem(attribute)?.textContent

private fun parseXMLFile(inputSteam: InputStream): Document? =
    DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(inputSteam)

private fun parseXMLFile(byteArray: ByteArray): Document? = parseXMLFile(byteArray.inputStream())
private fun parseXMLText(text: String): Document? = text.reader().runCatching {
    DocumentBuilderFactory.newInstance().newDocumentBuilder().parse(InputSource(this))
}.getOrNull()

val String.decodedURL: String get() = URLDecoder.decode(this, "UTF-8")
private fun String.asFileName(): String = this.replace("/", "_")

private fun ZipInputStream.entries() = generateSequence { nextEntry }

fun createEpubBook(inputStream: InputStream,block:((EpubBook?,Boolean,String)->Unit)) {
    val zipFile = ZipInputStream(inputStream).use { zipInputStream ->
        zipInputStream
            .entries()
            .filterNot { it.isDirectory }
            .associate { it.name to (it to zipInputStream.readBytes()) }
    }

    fun Exception.callback(block:((EpubBook?,Boolean,String)->Unit)):Throwable{
        block.invoke(null,false,message.toString())
        return this
    }

    val container =
        zipFile["META-INF/container.xml"] ?: throw Exception("META-INF/container.xml file missing").callback(block)

    val opfFilePath = parseXMLFile(container.second)
        ?.selectFirstTag("rootfile")
        ?.getAttributeValue("full-path")
        ?.decodedURL ?: throw Exception("Invalid container.xml file").callback(block)

    val opfFile = zipFile[opfFilePath] ?: throw Exception(".opf file missing").callback(block)

    val document = parseXMLFile(opfFile.second) ?: throw Exception(".opf file failed to parse data").callback(block)
    val metadata =
        document.selectFirstTag("metadata") ?: throw Exception(".opf file metadata section missing").callback(block)
    val manifest =
        document.selectFirstTag("manifest") ?: throw Exception(".opf file manifest section missing").callback(block)
    val spine =
        document.selectFirstTag("spine") ?: throw Exception(".opf file spine section missing").callback(block)

    val bookTitle = metadata.selectFirstChildTag("dc:title")?.textContent
        ?: throw Exception(".opf metadata title tag missing")
    val bookUrl = bookTitle.asFileName()
    val rootPath = File(opfFilePath).parentFile ?: File("")
    fun String.absPath() = File(rootPath, this).path.replace("""\""", "/").removePrefix("/")

    fun Map<String,EpubManifestItem>.coverByProperties():EpubImage?
        = values.asSequence()
            .filter { it.mediaType.startsWith("image/") }
            .find { it.properties == "cover-image" }
            ?.let { zipFile[it.href.absPath()] }
            ?.let { (entry, byteArray) -> EpubImage(path = entry.name, image = byteArray) }

    val covers = arrayOf("cover","cover-image")
    val chapterExtensions = listOf("xhtml", "xml", "html").map { ".$it" }

    fun String.filePrefix():String{
        val index = indexOf(".")
        return if(index!=-1) substring(0,index) else this
    }
    fun String.filePostfix():String{
        val index = lastIndexOf(".")
        return if(index!=-1 && index<length) substring(index,length) else this
    }

    fun Map<String,Pair<ZipEntry,ByteArray>>.cover():EpubImage?
         = keys.filter {
            it.filePostfix() !in chapterExtensions
        }.find {
            File(it).name.filePrefix().contains("cover")
        }?.let{ EpubImage(path = it,this[it]!!.second)}

    fun Map<String,EpubManifestItem>.coverById():EpubImage?
        = values.asSequence()
            .filter { it.mediaType.startsWith("image/") }
            .find { it.id in covers }
            ?.let { zipFile[it.href.absPath()] }
            ?.let { (entry, byteArray) -> EpubImage(path = entry.name, image = byteArray) }

    val items = manifest.selectChildTag("item").map {
        EpubManifestItem(
            id = it.getAttribute("id"),
            href = it.getAttribute("href").decodedURL,
            mediaType = it.getAttribute("media-type"),
            properties = it.getAttribute("properties")
        )
    }.associateBy { it.id }

    val idRef = spine.selectChildTag("itemref").map { it.getAttribute("idref") }

    var chapterIndex = 0
    val chapters = idRef
        .mapNotNull { items[it] }
        .filter { item -> chapterExtensions.any { item.href.endsWith(it, ignoreCase = true) } }
        .mapNotNull { zipFile[it.href.absPath()] }
        .mapIndexed { index, (entry, byteArray) ->
            val res = EpubXMLFileParser(entry.name, byteArray, zipFile).parse()
            // A full chapter usually is split in multiple sequential entries,
            // try to merge them and extract the main title of each one.
            // Is is not perfect but better than dealing with a table of contents
            val chapterTitle = res.title ?: if (index == 0) bookTitle else null
            if (chapterTitle != null)
                chapterIndex += 1

            TempEpubChapter(
                url = "$bookUrl/${entry.name}",
                title = chapterTitle,
                body = res.body,
                chapterIndex = chapterIndex,
            )
        }.groupBy {
            it.chapterIndex
        }.map { (_, list) ->
            EpubChapter(
                url = list.first().url,
                title = list.first().title!!,
                body = list.joinToString("\n\n") { it.body }
            )
        }.filter {
            it.body.isNotBlank()
        }

    val listedImages = items.values.asSequence()
        .filter { it.mediaType.startsWith("image/") }
        .mapNotNull { zipFile[it.href.absPath()] }
        .map { (entry, byteArray) -> EpubImage(path = entry.name, image = byteArray) }

    val imageExtensions = listOf("png", "gif", "raw", "png", "jpg", "jpeg", "webp", "bmp").map { ".$it" }
    val unlistedImages = zipFile.values.asSequence()
        .filterNot { (entry, _) -> entry.isDirectory }
        .filter { (entry, _) -> imageExtensions.any { entry.name.endsWith(it, ignoreCase = true) } }
        .map { (entry, byteArray) -> EpubImage(path = entry.name, image = byteArray) }

    val images = (listedImages + unlistedImages).distinctBy { it.path }

    val coverImage = items.coverByProperties()?:items.coverById()?:zipFile.cover()

    block(EpubBook(
        fileName = bookUrl,
        title = bookTitle,
        coverImagePath = coverImage?.path ?: "",
        chapters = chapters.toList(),
        images = images.toList()
    ),true,"")
}

/*fun importEpubToRepository(repository: Repository, epub: EpubBook) =
    CoroutineScope(Dispatchers.IO).launch {
        // First clean any previous entries from the book
        fun String.withLocalPrefix() = "local://${this}"

        val bookUrl = epub.fileName.withLocalPrefix()
        repository.bookChapters.chapters(bookUrl)
            .map { it.url }
            .let { repository.chapterBody.removeRows(it) }
        repository.bookChapters.removeAllFromBook(bookUrl)
        repository.libraryBooks.remove(bookUrl)

        // Insert new book data
        Book(
            title = epub.title,
            url = bookUrl,
            coverImageUrl = epub.coverImagePath.withLocalPrefix(),
            inLibrary = true
        ).let { repository.libraryBooks.insert(it) }

        epub.chapters
            .mapIndexed { i, it ->
                Chapter(
                    title = it.title,
                    url = it.url.withLocalPrefix(),
                    bookUrl = bookUrl,
                    position = i
                )
            }
            .let { repository.bookChapters.insert(it) }

        epub.chapters
            .map { ChapterBody(url = it.url.withLocalPrefix(), body = it.body) }
            .let { repository.chapterBody.insertReplace(it) }

        epub.images.map {
            async {
                val imgFile =
                    Paths.get(repository.settings.folderBooks.path, epub.fileName, it.path).toFile()
                imgFile.parentFile?.also { parent ->
                    parent.mkdirs()
                    if (parent.exists())
                        imgFile.writeBytes(it.image)
                }
            }
        }.awaitAll()
    }*/

