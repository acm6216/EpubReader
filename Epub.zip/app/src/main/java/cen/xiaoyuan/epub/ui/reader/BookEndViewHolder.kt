package cen.xiaoyuan.epub.ui.reader

import android.view.ViewGroup
import cen.xiaoyuan.epub.databinding.ReaderListItemSpecialTitleBinding
import cen.xiaoyuan.epub.utils.layoutInflater

class BookEndViewHolder private constructor(
    override val binding: ReaderListItemSpecialTitleBinding
): ReaderViewHolder<ReaderListItemSpecialTitleBinding,ReaderItem.BookEnd>(binding){

    override fun bind(item: ReaderItem.BookEnd,viewModel: ReaderViewModel){
        binding.root.setOnClickListener { }
        binding.executePendingBindings()
    }

    companion object{
        fun from(parent: ViewGroup) = BookEndViewHolder(
            ReaderListItemSpecialTitleBinding.inflate(parent.context.layoutInflater,parent,false)
        )
    }

}