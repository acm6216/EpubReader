package cen.xiaoyuan.epub.ui.viewmodel

import android.content.Context
import android.net.Uri
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cen.xiaoyuan.epub.core.EpubBook
import cen.xiaoyuan.epub.data.Book
import cen.xiaoyuan.epub.data.Chapter
import cen.xiaoyuan.epub.data.Progress
import cen.xiaoyuan.epub.data.usecase.*
import cen.xiaoyuan.epub.ui.reader.textToItemsConverter
import cen.xiaoyuan.epub.utils.WhileViewSubscribed
import cen.xiaoyuan.epub.utils.coverFolder
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.transform
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import javax.inject.Inject

@HiltViewModel
class LibraryViewModel @Inject constructor(
    private val bookInfoUseCase: BookInfoUseCase
):ViewModel() {

    val books = bookInfoUseCase.queryBooks()
        .stateIn(viewModelScope, WhileViewSubscribed, emptyList())

    val currentBook = MutableStateFlow<Book?>(null)
    val currentBookChapters = currentBook.transform { book ->
        emit(emptyList())
        book?.also {
            bookInfoUseCase.queryChapters(it.id).collect{ chapters -> emit(chapters) }
        }
    }

    fun release(){
        //currentBook.value = null
    }

    suspend fun findBook(id:Uri){
        release()
        withContext(Dispatchers.IO) {
            bookInfoUseCase.queryBook(id)?.let {
                currentBook.value = it
            }
        }
    }

    private fun insertBook(book: Book){
        viewModelScope.launch {
            bookInfoUseCase.insertBooks(listOf(book))
        }
    }

    private fun String.removeSeparator(): String = replace(File.separator, "")

    suspend fun addBook(uri: Uri,epubBook: EpubBook,context: Context){
        val coverPath = "${context.coverFolder.path}${File.separator}${this.hashCode()}-"
        var itemTotal = 0L
        insertBook("$coverPath${epubBook.coverImagePath.removeSeparator()}", epubBook, uri)
        insertBookReaderProgress(uri)
        epubBook.chapters.mapIndexed { index, epubChapter ->
            textToItemsConverter(
                chapterUrl = epubChapter.url,
                chapterPos = index,
                initialChapterItemIndex = 0,
                text = epubChapter.body
            ).let { list ->
                Chapter(
                    id = 0,
                    bookUri = uri,
                    itemIndex = itemTotal,
                    chapterTitle = epubChapter.title,
                    chapterIndex = index.toLong(),
                    currentChapterItem = list.size+2L
                ).also {
                    itemTotal+=list.size+2L
                }
            }
        }.also { insertChapters(it) }
        epubBook.images.find { epubBook.coverImagePath==it.path }?.also{
            val imgFile = File("$coverPath${it.path.removeSeparator()}")
            imgFile.parentFile?.also { parent ->
                parent.mkdirs()
                if (parent.exists())
                    imgFile.writeBytes(it.image)
            }
        }
    }

    private fun insertChapters(chapters:List<Chapter>){
        viewModelScope.launch {
            bookInfoUseCase.insertChapters(chapters)
        }
    }

    private fun insertBookReaderProgress(uri: Uri){
        viewModelScope.launch {
            bookInfoUseCase.insertReaderPosition(
                listOf(Progress(uri))
            )
        }
    }

    private fun insertBook(coverPath:String, epubBook: EpubBook, uri: Uri){
        insertBook(
            Book(
                id = uri,
                title = epubBook.title,
                coverPath = coverPath,
                fileName = epubBook.fileName,
                chapters = epubBook.chapters.size.toString()
            )
        )
    }

}