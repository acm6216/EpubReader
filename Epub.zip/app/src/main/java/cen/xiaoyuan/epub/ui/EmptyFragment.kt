package cen.xiaoyuan.epub.ui

import android.os.Bundle
import android.view.View
import cen.xiaoyuan.epub.databinding.FragmentEmptyBinding

class EmptyFragment:BaseFragment<FragmentEmptyBinding>() {

    override fun setBinding(): FragmentEmptyBinding = FragmentEmptyBinding.inflate(layoutInflater)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.executePendingBindings()
    }

    override fun launchFlow() {
        repeatWithViewLifecycle {

        }
    }

}