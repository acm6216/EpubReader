package cen.xiaoyuan.epub.ui.reader

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import cen.xiaoyuan.epub.core.EpubBook
import cen.xiaoyuan.epub.data.Book
import cen.xiaoyuan.epub.data.Chapter
import cen.xiaoyuan.epub.data.Progress
import cen.xiaoyuan.epub.data.usecase.BookInfoUseCase
import cen.xiaoyuan.epub.utils.WhileViewSubscribed
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class ReaderViewModel @Inject constructor(
    private val bookInfoUseCase: BookInfoUseCase
) : ViewModel() {

    private val currentBook = MutableStateFlow<Book?>(null)
    private val itemIndex = MutableStateFlow(0L)
    val isLoading = MutableStateFlow(false)
    private val currentProgress = currentBook.transform { book->
        emit(null)
        book?.also {
            bookInfoUseCase.queryBookReaderProgress(it.id).collect { progress ->
                emit(progress)
            }
        }
    }

    fun navigationToDetail(chapter: Chapter){
        _toDetail.trySend(chapter)
        openItemByIndex(chapter)
    }
    private val _toDetail = Channel<Chapter>(capacity = Channel.CONFLATED)
    val toDetail = _toDetail.receiveAsFlow()

    val progress = combine(currentProgress,itemIndex){ pro,index ->
        if(pro==null) null
        else Progress(
            id = pro.id,
            position = if(index!=0L) index else pro.position,
            chapterIndex = pro.chapterIndex
        )
    }.stateIn(viewModelScope, WhileViewSubscribed, null)

    val epubBook = MutableStateFlow<EpubBook?>(null)

    val epubContent = epubBook.transform { epub->
        emit(emptyList())
        epub?:return@transform
        isLoading.value = true
        val readerItem = ArrayList<ReaderItem>()
        epub.chapters.forEachIndexed { index, chapter ->
            readerItem.add(
                ReaderItem.Title(
                    chapterUrl = chapter.url,
                    chapterIndex = index,
                    chapterItemIndex = 0,
                    text = chapter.title
                )
            )
            readerItem.addAll(
                textToItemsConverter(
                    chapter.url,
                    index, 0,
                    chapter.body
                )
            )
            readerItem.add(
                ReaderItem.Divider(
                    chapterUrl = chapter.url,
                    chapterIndex = index
                )
            )
        }
        readerItem.removeLast()
        isLoading.value = false
        emit(readerItem)
    }.stateIn(viewModelScope, WhileViewSubscribed, emptyList())

    fun release() {
        //epubBook.value = null
    }

    fun updateLastReaderIndex(index:Int){
        val pro = progress.value?:return
        itemIndex.value = index.toLong()
        viewModelScope.launch {
            bookInfoUseCase.updateProgress(
                Progress(
                    id = pro.id,
                    position = index.toLong(),
                    chapterIndex = pro.chapterIndex
                )
            )
        }
    }

    fun openItemByIndex(chapter: Chapter) {
        itemIndex.value = chapter.itemIndex
        viewModelScope.launch {
            bookInfoUseCase.updateProgressByUri(chapter.bookUri, chapter.itemIndex)
        }
    }

    fun openEpub(epub: EpubBook?,book: Book) {
        //currentBook.value = null
        //epubBook.value = null
        viewModelScope.launch {
            currentBook.value = book
            epubBook.value = epub
        }
    }
}