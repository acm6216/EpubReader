package cen.xiaoyuan.epub.ui.reader

import android.view.ViewGroup
import cen.xiaoyuan.epub.databinding.ReaderListItemDividerBinding
import cen.xiaoyuan.epub.utils.layoutInflater

class DividerViewHolder private constructor(
    override val binding: ReaderListItemDividerBinding
): ReaderViewHolder<ReaderListItemDividerBinding,ReaderItem.Divider>(binding){

    override fun bind(readerItem: ReaderItem.Divider,viewModel: ReaderViewModel){
        binding.root.setOnClickListener { }
        binding.executePendingBindings()
    }

    companion object{
        fun from(parent: ViewGroup) = DividerViewHolder(
            ReaderListItemDividerBinding.inflate(parent.context.layoutInflater,parent,false)
        )
    }

}