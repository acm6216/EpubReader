package cen.xiaoyuan.epub.ui.reader

import android.view.ViewGroup
import cen.xiaoyuan.epub.databinding.ReaderListItemTitleBinding
import cen.xiaoyuan.epub.utils.layoutInflater

class TitleViewHolder private constructor(
    override val binding: ReaderListItemTitleBinding
): ReaderViewHolder<ReaderListItemTitleBinding, ReaderItem.Title>(binding) {

    override fun bind(item: ReaderItem.Title,viewModel: ReaderViewModel){
        binding.title = item
        binding.executePendingBindings()
    }

    companion object{
        fun from(parent: ViewGroup) = TitleViewHolder(
            ReaderListItemTitleBinding.inflate(parent.context.layoutInflater,parent,false)
        )
    }

}