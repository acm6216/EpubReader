package cen.xiaoyuan.epub

object Config {
    const val TEMP_FILE = "temp.epub"
    const val EPUB_FILE_MIME = "application/epub+zip"
}